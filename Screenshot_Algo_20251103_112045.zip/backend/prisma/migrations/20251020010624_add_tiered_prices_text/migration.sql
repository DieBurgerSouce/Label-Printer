-- AlterTable
ALTER TABLE "products" ADD COLUMN     "tieredPricesText" TEXT;
