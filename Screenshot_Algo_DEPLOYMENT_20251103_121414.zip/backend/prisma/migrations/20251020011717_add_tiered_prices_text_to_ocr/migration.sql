-- AlterTable
ALTER TABLE "ocr_results" ADD COLUMN     "tieredPricesText" TEXT;
