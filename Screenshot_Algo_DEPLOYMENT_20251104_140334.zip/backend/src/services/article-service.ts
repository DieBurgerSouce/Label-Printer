/**
 * Article Service - Database access for articles/products
 */

import { prisma } from '../lib/supabase.js';

export interface Article {
  id: string;
  articleNumber: string;
  productName: string;
  description?: string;
  price?: number;
  currency?: string;
  imageUrl?: string;
  category?: string;
  tieredPrices?: Array<{ quantity: number; price: number }>;
  tieredPricesText?: string;
  sourceUrl?: string; // Original product URL
}

export class ArticleService {
  static async getArticleById(id: string): Promise<Article | null> {
    try {
      const product = await prisma.product.findUnique({
        where: { id }
      });

      if (!product) {
        return null;
      }

      // Map Prisma product to Article interface
      return {
        id: product.id,
        articleNumber: product.articleNumber,
        productName: product.productName,
        description: product.description || undefined,
        price: product.price || undefined,
        currency: product.currency || 'EUR',
        imageUrl: product.imageUrl || undefined,
        category: product.category || undefined,
        tieredPrices: product.tieredPrices as any || undefined,
        tieredPricesText: product.tieredPricesText || undefined,
        sourceUrl: product.sourceUrl || undefined,
      };
    } catch (error) {
      console.error(`Error fetching article ${id}:`, error);
      return null;
    }
  }
}
