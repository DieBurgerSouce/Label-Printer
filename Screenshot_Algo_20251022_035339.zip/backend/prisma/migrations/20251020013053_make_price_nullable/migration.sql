-- AlterTable
ALTER TABLE "products" ALTER COLUMN "price" DROP NOT NULL;
